import java.util.ArrayList;
import java.util.List;

class Direction {
    private String name;
    private List<Doctor> doctors;

    public Direction(String name) {
        this.name = name;
        this.doctors = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<Doctor> getAvailableDoctors() {
        List<Doctor> availableDoctors = new ArrayList<>();
        for (Doctor doctor : doctors) {
            if (doctor.getRemainingTickets() > 0) {
                availableDoctors.add(doctor);
            }
        }
        return availableDoctors;
    }

    public void addDoctor(Doctor doctor) {
        doctors.add(doctor);
    }
}