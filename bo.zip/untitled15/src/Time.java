class Time {
    private String timeSlot;
    private boolean available;

    public Time(String timeSlot) {
        this.timeSlot = timeSlot;
        this.available = true;
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}