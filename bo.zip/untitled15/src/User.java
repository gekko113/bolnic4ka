class User {
    private String name;
    private Ticket ticket;

    public User(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Ticket getTicket() {
        return ticket;
    }

    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }
}