class Ticket {
    private static int ticketCounter = 1;
    private int ticketNumber;
    private Time time;
    private Doctor doctor;
    private User user;

    public Ticket(Time time, Doctor doctor, User user) {
        this.ticketNumber = ticketCounter++;
        this.time = time;
        this.doctor = doctor;
        this.user = user;
        doctor.addTicket(this);
    }

    public int getTicketNumber() {
        return ticketNumber;
    }

    public Time getTime() {
        return time;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public User getUser() {
        return user;
    }
}