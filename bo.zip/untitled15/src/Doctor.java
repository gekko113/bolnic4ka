import java.util.ArrayList;
import java.util.List;

class Doctor {
    private String name;
    private int maxTickets;
    private List<Time> availableTimes;
    private List<Ticket> tickets;
    private String cabinet;
    private int floor;

    public Doctor(String name, int maxTickets, String cabinet, int floor) {
        this.name = name;
        this.maxTickets = maxTickets;
        this.availableTimes = initializeAvailableTimes();
        this.tickets = new ArrayList<>();
        this.cabinet = cabinet;
        this.floor = floor;
    }

    private List<Time> initializeAvailableTimes() {
        List<Time> times = new ArrayList<>();
        times.add(new Time("10:00"));
        times.add(new Time("11:00"));
        times.add(new Time("12:00"));
        return times;
    }

    public String getName() {
        return name;
    }

    public List<Time> getAvailableTimes() {
        return availableTimes;
    }

    public int getRemainingTickets() {
        return maxTickets - tickets.size();
    }

    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }

    public void removeAvailableTime(Time time) {
        availableTimes.remove(time);
    }
    public String getCabinet() {
        return cabinet;
    }

    public void setCabinet(String cabinet) {
        this.cabinet = cabinet;
    }

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public void printPatients() {
        for (Ticket ticket : tickets) {
            System.out.println("Пациент: " + ticket.getUser().getName() + ", время: " +
                    ticket.getTime().getTimeSlot() + ", кабинет: " + cabinet + ", этаж: " + floor);
        }
    } }

