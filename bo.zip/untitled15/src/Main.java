import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<User> users = new ArrayList<>();
        List<Direction> directions = initializeDirections();

        while (true) {
            System.out.println("Выберите действие:");
            System.out.println("1. Регистрация");
            System.out.println("2. Вход");
            System.out.println("3. Вход для врачей");
            System.out.println("4. Выход");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    registerUser(scanner, users, directions);
                    break;
                case 2:
                    loginUser(scanner, users);
                    break;
                case 3:
                    loginDoctor(scanner, directions);
                    break;
                case 4:
                    System.out.println("До свидания!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Неверный выбор.");
            }
        }
    }

    private static void registerUser(Scanner scanner, List<User> users, List<Direction> directions) {
        System.out.println("Здравствуйте, введите имя и фамилию: ");
        String name = scanner.nextLine();
        User user = new User(name);
        users.add(user);

        System.out.println("Выберите направление:");
        for (int i = 0; i < directions.size(); i++) {
            System.out.println((i + 1) + ". " + directions.get(i).getName());
        }
        int directionChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        Direction chosenDirection = directions.get(directionChoice - 1);

        System.out.println("Выберите врача:");
        List<Doctor> availableDoctors = chosenDirection.getAvailableDoctors();
        for (int i = 0; i < availableDoctors.size(); i++) {
            Doctor doctor = availableDoctors.get(i);
            System.out.println((i + 1) + ". " + doctor.getName() + ", кабинет: " + doctor.getCabinet() + ", этаж: " + doctor.getFloor());
        }
        int doctorChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        Doctor chosenDoctor = availableDoctors.get(doctorChoice - 1);

        System.out.println("Выберите время:");
        List<Time> availableTimes = chosenDoctor.getAvailableTimes();
        for (int i = 0; i < availableTimes.size(); i++) {
            Time time = availableTimes.get(i);
            if (time.isAvailable()) {
                System.out.println((i + 1) + ". " + time.getTimeSlot());
            }
        }
        int timeChoice = scanner.nextInt();
        scanner.nextLine();
        Time chosenTime = availableTimes.get(timeChoice - 1);

        chosenTime.setAvailable(false);

        Ticket ticket = new Ticket(chosenTime, chosenDoctor, user);
        user.setTicket(ticket);
        System.out.println("Вы успешно записаны. Номер вашего талона: " + ticket.getTicketNumber());
        System.out.println("Ваш врач: " + chosenDoctor.getName() + ", кабинет: " + chosenDoctor.getCabinet() + ", этаж: " + chosenDoctor.getFloor());
    }


    private static void loginUser(Scanner scanner, List<User> users) {
        System.out.println("Введите вашу фамилию и имя: ");
        String name = scanner.nextLine();
        Optional<User> optionalUser = users.stream().filter(u -> u.getName().equals(name)).findFirst();

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            Ticket ticket = user.getTicket();
            if (ticket != null) {
                Doctor doctor = ticket.getDoctor();
                System.out.println("Добро пожаловать, " + name + "! Ваш врач: " + doctor.getName() +
                        ", время: " + ticket.getTime().getTimeSlot() +
                        ", кабинет: " + doctor.getCabinet() +
                        ", этаж: " + doctor.getFloor() + "," + " талон номер: " + ticket.getTicketNumber());
            } else {
                System.out.println("Вы еще не записаны к врачу.");
            }
        } else {
            System.out.println("Пользователь с таким именем не найден.");
        }
    }

    private static void loginDoctor(Scanner scanner, List<Direction> directions) {
        System.out.println("Введите фамилию врача:");
        String doctorName = scanner.nextLine();

        for (Direction direction : directions) {
            for (Doctor doctor : direction.getAvailableDoctors()) {
                if (doctor.getName().equalsIgnoreCase(doctorName)) {
                    System.out.println("Врач: " + doctor.getName() + ", кабинет: " + doctor.getCabinet() + ", этаж: " + doctor.getFloor());
                    System.out.println("Пациенты, записанные к вам:");
                    doctor.printPatients();
                    return;
                }
            }
        }

        System.out.println("Врач с таким именем не найден.");
    }


    private static List<Direction> initializeDirections() {
        List<Direction> directions = new ArrayList<>();

        Direction stomatology = new Direction("Стоматология");
        stomatology.addDoctor(new Doctor("Иванов", 2, "101", 1));
        stomatology.addDoctor(new Doctor("Петров", 1, "202", 2));
        stomatology.addDoctor(new Doctor("Сидоров", 3, "303", 3));
        directions.add(stomatology);

        Direction neurology = new Direction("Неврология");
        neurology.addDoctor(new Doctor("Смирнов", 2, "104",1));
        neurology.addDoctor(new Doctor("Кузнецов", 2, "205",2));
        neurology.addDoctor(new Doctor("Соколов", 3,"306",3));
        directions.add(neurology);

        Direction surgery = new Direction("Хирургия");
        surgery.addDoctor(new Doctor("Васильев", 1, "107",1));
        surgery.addDoctor(new Doctor("Попов", 3,"208",2));
        surgery.addDoctor(new Doctor("Морозов", 2,"309",3));
        directions.add(surgery);

        return directions;
    }
}